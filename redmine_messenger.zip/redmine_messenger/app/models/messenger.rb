# frozen_string_literal: true

class Messenger
  include Redmine::I18n

  # Notification "slot" definitions. The plugin always exposes two slots so a
  # single Redmine event can be delivered to two destinations at the same time
  # (e.g. Discord + LINE).
  ENDPOINT_SLOTS = [
    { suffix: '',
      url_key: :messenger_url,
      type_key: :messenger_type,
      token_key: :messenger_token,
      channel_key: :messenger_channel,
      icon_key: :messenger_icon,
      username_key: :messenger_username },
    { suffix: '2',
      url_key: :messenger_url2,
      type_key: :messenger_type2,
      token_key: :messenger_token2,
      channel_key: :messenger_channel2,
      icon_key: :messenger_icon2,
      username_key: :messenger_username2 }
  ].freeze

  SUPPORTED_TYPES = %w[slack line].freeze

  class << self
    def markup_format(text)
      # TODO: output format should be markdown, but at the moment there is no
      #       solution without using pandoc (http://pandoc.org/), which requires
      #       packages on os level
      #
      # Redmine::WikiFormatting.html_parser.to_text(text)

      text = text.to_s.dup

      # @see https://api.slack.com/reference/surfaces/formatting#escaping

      text.gsub! '&', '&amp;'
      text.gsub! '<', '&lt;'
      text.gsub! '>', '&gt;'

      text
    end

    def default_url_options
      { only_path: true, script_name: Redmine::Utils.relative_url_root }
    end

    # Public entry point used by the patches.
    #
    # The +channels+ and +url+ arguments are kept for backwards compatibility
    # and represent the *primary* slot. The secondary slot is resolved
    # internally from the project's MessengerSetting (or, fall back to the
    # global plugin settings).
    #
    # +options+ may include:
    #   * :project    - Redmine project (used for setting/url resolution)
    #   * :attachment - Slack-style attachment hash (text + fields)
    #   * :line_card  - structured payload used to build a LINE Flex Message;
    #                   when absent the LINE slot falls back to plain text.
    def speak(msg, channels, url, options = {})
      project = options[:project]
      attachment = options[:attachment]
      line_card = options[:line_card]
      delivered = false

      ENDPOINT_SLOTS.each_with_index do |slot, index|
        endpoint = endpoint_for(project, slot)

        # For the primary slot honor the explicit URL/channels passed in (this
        # preserves the previous public API and the per-call channel append
        # done by issue_patch for direct user messages).
        if index.zero?
          endpoint[:url] = url if url.present?
          endpoint[:channels] = Array(channels).compact.uniq if channels.present?
        end

        delivered = true if deliver_to(endpoint, msg, attachment, project, line_card)
      end

      delivered
    end

    # True when at least one of the two slots has enough configuration to
    # deliver a message for this project.
    def deliverable?(project)
      ENDPOINT_SLOTS.any? { |slot| slot_deliverable?(project, slot) }
    end

    def object_url(obj)
      if Setting.host_name.to_s =~ %r{\A(https?://)?(.+?)(:(\d+))?(/.+)?\z}i
        host = Regexp.last_match 2
        port = Regexp.last_match 4
        prefix = Regexp.last_match 5
        Rails.application.routes.url_for obj.event_url(host: host, protocol: Setting.protocol, port: port, script_name: prefix)
      else
        Rails.application.routes.url_for obj.event_url(host: Setting.host_name, protocol: Setting.protocol, script_name: '')
      end
    end

    def url_for_project(proj)
      url_for_slot proj, ENDPOINT_SLOTS[0]
    end

    def url_for_project_secondary(proj)
      url_for_slot proj, ENDPOINT_SLOTS[1]
    end

    def project_url_markdown(project)
      "<#{object_url project}|#{project.name}>"
    end

    def url_markdown(obj, name)
      "<#{object_url obj}|#{name}>"
    end

    def textfield_for_project(proj, config)
      return if proj.blank?

      # project based
      pm = proj.messenger_setting
      return pm.send config if !pm.nil? && pm.send(config).present?

      default_textfield proj, config
    end

    def default_textfield(proj, config)
      # parent project based
      parent_field = textfield_for_project proj.parent, config
      return parent_field if parent_field.present?
      return RedmineMessenger.setting config if RedmineMessenger.setting(config).present?

      ''
    end

    def channels_for_project(proj)
      channels_for_slot proj, ENDPOINT_SLOTS[0]
    end

    def channels_for_project_secondary(proj)
      channels_for_slot proj, ENDPOINT_SLOTS[1]
    end

    def type_for_project(proj, config = :messenger_type)
      default_type = RedmineMessenger.setting(config).presence || 'slack'
      return default_type if proj.blank?

      pm = proj.messenger_setting
      return pm.send(config) if !pm.nil? && pm.send(config).present?

      if proj.parent.present?
        parent_type = type_for_project(proj.parent, config)
        return parent_type if parent_type.present?
      end

      default_type
    end

    def setting_for_project(proj, config)
      return false if proj.blank?

      @setting_found = 0
      # project based
      pm = proj.messenger_setting
      unless pm.nil? || pm.send(config).zero?
        @setting_found = 1
        return false if pm.send(config) == 1
        return true if pm.send(config) == 2
        # 0 = use system based settings
      end
      default_project_setting proj, config
    end

    def default_project_setting(proj, config)
      if proj.present? && proj.parent.present?
        parent_setting = setting_for_project proj.parent, config
        return parent_setting if @setting_found == 1
      end
      # system based
      return true if RedmineMessenger.setting(config).present? && RedmineMessenger.setting?(config)

      false
    end

    def attachment_text_from_journal(journal)
      obj = journal.details.detect { |j| j.prop_key == 'description' && j.property == 'attr' }
      text = obj.value if obj.present?
      text.present? ? markup_format(text) : nil
    end

    def detail_to_field(detail, prj = nil)
      field_format = nil
      key = nil
      escape = true
      value = detail.value.to_s
      if detail.property == 'cf'
        key = CustomField.find(detail.prop_key)&.name
        unless key.nil?
          title = key
          field_format = CustomField.find(detail.prop_key)&.field_format

          value = IssuesController.helpers.format_value detail.value, detail.custom_field if detail.value.present?
        end
      elsif detail.property == 'attachment'
        key = 'attachment'
        title = I18n.t :label_attachment
        value = detail.value.to_s
      elsif detail.property == 'attr' &&
            detail.prop_key == 'db_relation'
        return { short: true } unless setting_for_project prj, :post_db

        title = I18n.t :field_db_relation
        if detail.value.present?
          entry = DbEntry.visible.find_by id: detail.value
          value = entry.present? ? entry.name : detail.value.to_s
        end
      elsif detail.property == 'attr' &&
            detail.prop_key == 'password_relation'
        return { short: true } unless setting_for_project prj, :post_password

        title = I18n.t :field_password_relation
        if detail.value.present?
          entry = Password.visible.find_by id: detail.value
          value = entry.present? ? entry.name : detail.value.to_s
        end
      else
        key = detail.prop_key.to_s.sub '_id', ''
        title = case key
                when 'parent'
                  I18n.t "field_#{key}_issue"
                when 'copied_from'
                  I18n.t "label_#{key}"
                else
                  I18n.t "field_#{key}"
                end
        value = detail.value.to_s
      end

      short = true
      case key
      when 'title', 'subject'
        short = false
      when 'description'
        return
      when 'tracker'
        value = object_field_value Tracker, detail.value
      when 'estimated_hours'
        value = format_hours(value.is_a?(String) ? (value.to_hours || value) : value)
      when 'project'
        value = object_field_value Project, detail.value
      when 'status'
        value = object_field_value IssueStatus, detail.value
      when 'priority'
        value = object_field_value IssuePriority, detail.value
      when 'category'
        value = object_field_value IssueCategory, detail.value
      when 'assigned_to', 'author'
        value = object_field_value Principal, detail.value
      when 'fixed_version'
        value = object_field_value Version, detail.value
      when 'attachment'
        attachment = Attachment.find_by id: detail.prop_key
        value = if attachment.present?
                  escape = false
                  "<#{object_url attachment}|#{markup_format attachment.filename}>"
                else
                  detail.prop_key.to_s
                end

      when 'parent', 'copied_from'
        issue = Issue.find_by id: detail.value
        value = if issue.present?
                  escape = false
                  "<#{object_url issue}|#{markup_format issue}>"
                else
                  detail.value.to_s
                end
      end

      value = object_field_value Version, detail.value if detail.property == 'cf' && field_format == 'version'
      value = if value.present?
                if escape
                  markup_format value
                else
                  value
                end
              else
                '-'
              end

      result = { title: title, value: value }
      result[:short] = true if short
      result
    end

    def mentions(project, text)
      names = textfield_for_project(project, :default_mentions).split(',')
                                                               .map { |m| names.push m.strip }
      names += extract_usernames text unless text.nil?
      names.present? ? " To: #{names.uniq.join ', '}" : nil
    end

    private

    # Build the resolved configuration for a single endpoint slot.
    def endpoint_for(project, slot)
      {
        slot: slot,
        url: url_for_slot(project, slot),
        type: (type_for_project(project, slot[:type_key]).presence || 'slack').to_s,
        token: project_or_global_text(project, slot[:token_key]),
        channels: channels_for_slot(project, slot),
        icon: project_or_global_text(project, slot[:icon_key]),
        username: project_or_global_text(project, slot[:username_key])
      }
    end

    # Like textfield_for_project but also falls back to the global plugin
    # setting when no project is given (used by endpoint_for so LINE tokens
    # configured only at the global level still apply).
    def project_or_global_text(project, key)
      value = textfield_for_project(project, key)
      return value if value.present?

      RedmineMessenger.setting(key)
    end

    # Send a single notification to a single endpoint slot.
    # Returns true if a delivery job was actually enqueued.
    def deliver_to(endpoint, msg, attachment, project, line_card = nil)
      return false if endpoint[:url].blank?

      case endpoint[:type]
      when 'line'
        deliver_line endpoint, msg, attachment, line_card
      else
        deliver_slack endpoint, msg, attachment, project
      end
    end

    # Slack-compatible (Slack / Discord / Rocket.Chat / Mattermost) outgoing
    # webhook payload. Requires at least one channel to send to.
    def deliver_slack(endpoint, msg, attachment, _project)
      channels = endpoint[:channels]
      return false if channels.blank?

      params = { text: msg, link_names: 1 }
      params[:username] = endpoint[:username] if endpoint[:username].present?
      params[:attachments] = attachment.is_a?(Hash) && attachment.any? ? [attachment] : []

      icon = endpoint[:icon]
      if icon.present?
        if icon.start_with? ':'
          params[:icon_emoji] = icon
        else
          params[:icon_url] = icon
        end
      end

      channels.each do |channel|
        per_channel = params.merge channel: channel
        MessengerDeliverJob.perform_later endpoint[:url], per_channel, 'type' => 'slack'
      end
      true
    end

    # LINE Messaging API: https://developers.line.biz/en/reference/messaging-api/
    # Endpoint URL is typically:
    #   https://api.line.me/v2/bot/message/broadcast
    # or, if pushing to a specific user/group/room, use the push endpoint and
    # put the recipient ID in the channel field; the channel is then injected
    # into the JSON body as the +to+ field.
    #
    # When +line_card+ is supplied, a Flex Message bubble is sent (rendered as
    # a card in the LINE app). Otherwise the message is delivered as plain
    # text built from +msg+ and +attachment+.
    def deliver_line(endpoint, msg, attachment, line_card = nil)
      message = if line_card.is_a?(Hash) && line_card.any?
                  build_line_flex line_card
                else
                  { type: 'text', text: build_line_text(msg, attachment) }
                end

      payload = { messages: [message] }

      recipients = endpoint[:channels].is_a?(Array) ? endpoint[:channels].reject { |c| c.to_s.strip.empty? } : []

      job_options = { 'type' => 'line', 'token' => endpoint[:token].to_s }

      if recipients.empty?
        # Broadcast endpoint takes no `to` field.
        MessengerDeliverJob.perform_later endpoint[:url], payload, job_options
      else
        recipients.each do |recipient|
          per_recipient = payload.merge to: recipient
          MessengerDeliverJob.perform_later endpoint[:url], per_recipient, job_options
        end
      end

      true
    end

    # Plain-text fallback when no structured line_card is available.
    def build_line_text(msg, attachment)
      text = clean_line_text msg.to_s

      if attachment.is_a?(Hash)
        text << "\n#{clean_line_text attachment[:text]}" if attachment[:text].present?

        Array(attachment[:fields]).each do |field|
          next unless field.is_a?(Hash)

          title = field[:title].to_s
          value = clean_line_text(field[:value].to_s)
          next if title.empty? && value.empty?

          text << "\n#{title}: #{value}".rstrip
        end
      end

      text
    end

    # Convert Slack-flavored markup into clean text for LINE:
    #   <url|label>  -> "label"
    #   <url>        -> "url"
    #   *bold*       -> "bold"
    #   _italic_     -> "italic"
    #   ~strike~     -> "strike"
    #   `code`       -> "code"
    def clean_line_text(str)
      s = str.to_s
      s = s.gsub(/<([^|<>\s]+)\|([^<>]+)>/, '\\2')
      s = s.gsub(/<([^|<>\s]+)>/, '\\1')
      s = s.gsub(/(?<![\w*])\*([^\s*][^*]*?[^\s*]|[^\s*])\*(?![\w*])/, '\\1')
      s = s.gsub(/(?<![\w_])_([^\s_][^_]*?[^\s_]|[^\s_])_(?![\w_])/, '\\1')
      s = s.gsub(/(?<![\w~])~([^\s~][^~]*?[^\s~]|[^\s~])~(?![\w~])/, '\\1')
      s.gsub(/`([^`]+)`/, '\\1')
    end

    # Build a LINE Flex Message bubble from a structured line_card hash.
    # Expected keys:
    #   :action       - :created or :updated
    #   :entity_type  - :issue, :wiki, :contact, :db, :password
    #   :title        - bold subject line ("Bug #42: Login fails")
    #   :url          - link to the entity in Redmine
    #   :user         - actor name
    #   :project_name - project display name (header)
    #   :description  - free-form body text (issue description, wiki comment, ...)
    #   :fields       - [{ label:, value: }, ...]
    def build_line_flex(card)
      action_label = action_label_for card[:action]
      entity_label = entity_label_for card[:entity_type]
      header_color = action_color_for card[:action]
      project_name = card[:project_name].to_s
      title        = clean_line_text(card[:title]).strip
      user         = clean_line_text(card[:user]).strip
      description  = clean_line_text(card[:description]).strip

      header_subtitle = [entity_label, action_label].reject(&:empty?).join(' ')

      header = {
        type: 'box',
        layout: 'vertical',
        backgroundColor: header_color,
        paddingAll: '12px',
        contents: [
          { type: 'text', text: project_name.empty? ? ' ' : project_name,
            color: '#FFFFFF', size: 'sm', weight: 'bold', wrap: true }
        ]
      }
      unless header_subtitle.empty?
        header[:contents] << { type: 'text', text: header_subtitle,
                               color: '#FFFFFFCC', size: 'xs', margin: 'xs' }
      end

      body_contents = []
      body_contents << { type: 'text', text: title.empty? ? ' ' : title,
                         weight: 'bold', size: 'md', wrap: true, color: '#1F1F1F' }

      unless user.empty?
        actor_line = user_action_line(user, card[:action])
        body_contents << { type: 'text', text: actor_line, size: 'xs',
                           color: '#888888', margin: 'xs' }
      end

      unless description.empty?
        body_contents << { type: 'separator', margin: 'md' }
        body_contents << { type: 'text', text: truncate_for_line(description, 280),
                           size: 'sm', color: '#555555', wrap: true, margin: 'md' }
      end

      field_rows = build_flex_field_rows card[:fields]
      unless field_rows.empty?
        body_contents << { type: 'separator', margin: 'md' }
        body_contents << { type: 'box', layout: 'vertical', spacing: 'sm',
                           margin: 'md', contents: field_rows }
      end

      bubble = {
        type: 'bubble',
        size: 'kilo',
        header: header,
        body: { type: 'box', layout: 'vertical', spacing: 'sm',
                paddingAll: '16px', contents: body_contents }
      }

      if card[:url].present?
        bubble[:footer] = {
          type: 'box', layout: 'vertical', paddingAll: '8px', spacing: 'sm',
          contents: [
            { type: 'button', style: 'primary', color: header_color, height: 'sm',
              action: { type: 'uri', label: 'Redmine で開く', uri: card[:url].to_s } }
          ]
        }
      end

      alt_summary = [project_name, header_subtitle, title].reject { |s| s.to_s.empty? }.join(' / ')
      alt_summary = title if alt_summary.empty?

      { type: 'flex', altText: truncate_for_line(alt_summary, 380),
        contents: bubble }
    end

    def build_flex_field_rows(fields)
      return [] unless fields.is_a?(Array)

      fields.each_with_object([]) do |field, rows|
        next unless field.is_a?(Hash)

        label = field[:label].to_s
        value = clean_line_text(field[:value].to_s).strip
        next if label.empty? && value.empty?

        rows << {
          type: 'box',
          layout: 'baseline',
          spacing: 'sm',
          contents: [
            { type: 'text', text: label.empty? ? ' ' : label,
              size: 'xs', color: '#888888', flex: 2, wrap: true },
            { type: 'text', text: value.empty? ? '-' : truncate_for_line(value, 120),
              size: 'xs', color: '#333333', flex: 5, wrap: true }
          ]
        }
      end
    end

    def truncate_for_line(str, max)
      s = str.to_s
      return s if s.length <= max

      "#{s[0, max - 1]}…"
    end

    def user_action_line(user, action)
      case action.to_s
      when 'created' then "#{user} さんが作成しました"
      when 'updated' then "#{user} さんが更新しました"
      else
        action.to_s.empty? ? user : "#{user} (#{action})"
      end
    end

    def action_label_for(action)
      case action.to_s
      when 'created' then '作成'
      when 'updated' then '更新'
      else action.to_s
      end
    end

    def action_color_for(action)
      case action.to_s
      when 'created' then '#06C755'
      when 'updated' then '#1F8FFF'
      else '#888888'
      end
    end

    def entity_label_for(type)
      case type.to_s
      when 'issue'    then 'チケット'
      when 'wiki'     then 'Wiki'
      when 'contact'  then 'コンタクト'
      when 'db'       then 'DB エントリ'
      when 'password' then 'パスワード'
      else ''
      end
    end

    def url_for_slot(proj, slot)
      key = slot[:url_key]
      if proj.present?
        pm = proj.messenger_setting
        return pm.send(key) if !pm.nil? && pm.send(key).present?

        if proj.parent.present?
          parent_url = url_for_slot proj.parent, slot
          return parent_url if parent_url.present?
        end
      end
      RedmineMessenger.setting(key).presence
    end

    def channels_for_slot(proj, slot)
      key = slot[:channel_key]
      if proj.present?
        pm = proj.messenger_setting
        if !pm.nil? && pm.send(key).present?
          return [] if pm.send(key) == '-'

          return pm.send(key).split(',').map(&:strip).uniq
        end

        if proj.parent.present?
          parent_channel = channels_for_slot proj.parent, slot
          return parent_channel if parent_channel.present?
        end
      end

      global = RedmineMessenger.setting(key)
      if global.present? && global != '-'
        return global.split(',').map(&:strip).uniq
      end

      []
    end

    def slot_deliverable?(project, slot)
      url = url_for_slot(project, slot)
      return false if url.blank?

      type = (type_for_project(project, slot[:type_key]).presence || 'slack').to_s
      return true if type == 'line'

      channels_for_slot(project, slot).present?
    end

    def object_field_value(klass, id)
      obj = klass.find_by id: id
      obj.nil? ? id.to_s : obj.to_s
    end

    def extract_usernames(text)
      return [] if text.blank?

      # messenger usernames may only contain lowercase letters, numbers,
      # dashes, dots and underscores and must start with a letter or number.
      text.scan(/@[a-z0-9][a-z0-9_\-.]*/).uniq
    end
  end
end
