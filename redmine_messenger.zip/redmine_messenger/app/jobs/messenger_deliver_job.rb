# frozen_string_literal: true

require 'net/http'
require 'uri'

class MessengerDeliverJob < ActiveJob::Base
  queue_as :default

  # +options+ may include:
  #   * 'type'  - 'slack' (default) or 'line'
  #   * 'token' - Bearer token used for LINE Messaging API
  #
  # ActiveJob serialises hashes with string keys, so callers should pass
  # string keys to keep the contract obvious.
  def perform(url, params, options = {})
    options ||= {}
    type = (options['type'] || options[:type] || 'slack').to_s

    case type
    when 'line'
      deliver_line url, params, options['token'] || options[:token]
    else
      deliver_slack url, params
    end
  end

  private

  # Slack-compatible incoming webhook (Slack / Discord / Rocket.Chat / Mattermost).
  def deliver_slack(url, params)
    perform_request(url) do |req|
      req.set_form_data payload: params.to_json
    end
  end

  # LINE Messaging API: JSON body with Bearer auth.
  def deliver_line(url, params, token)
    perform_request(url) do |req|
      req['Content-Type'] = 'application/json'
      req['Authorization'] = "Bearer #{token}" if token.to_s.strip != ''
      req.body = params.to_json
    end
  end

  def perform_request(url)
    uri = URI url
    http_options = { use_ssl: uri.scheme == 'https' }
    http_options[:verify_mode] = OpenSSL::SSL::VERIFY_NONE unless RedmineMessenger.setting? :messenger_verify_ssl
    begin
      req = Net::HTTP::Post.new uri
      yield req
      Net::HTTP.start uri.hostname, uri.port, http_options do |http|
        response = http.request req
        Rails.logger.warn response.inspect unless [Net::HTTPSuccess, Net::HTTPRedirection, Net::HTTPOK].include? response
      end
    rescue StandardError => e
      Rails.logger.warn "cannot connect to #{url}"
      Rails.logger.warn e
    end
  end
end
