# Messenger plugin for Redmine

This plugin posts updates to issues in your Redmine installation to [Slack](https://slack.com/), [Rocket.Chat](https://rocket.chat/), [Discord](https://discordapp.com/), [Mattermost](https://about.mattermost.com/) or [LINE](https://developers.line.biz/en/docs/messaging-api/) channels.

Notifications can be delivered to **two destinations at the same time** (e.g. Discord *and* LINE). Each of the two destination "slots" can independently be configured as either a Slack-compatible webhook or LINE Messaging API.

[![Rate at redmine.org](https://img.shields.io/badge/rate%20at-redmine.org-blue.svg?style=fla)](https://www.redmine.org/plugins/redmine_messenger) [![Run Linters](https://github.com/AlphaNodes/redmine_messenger/workflows/Run%20Linters/badge.svg)](https://github.com/AlphaNodes/redmine_messenger/actions?query=workflow%3A%22Run+Linters%22) [![Tests](https://github.com/AlphaNodes/redmine_messenger/actions/workflows/tests.yml/badge.svg)](https://github.com/AlphaNodes/redmine_messenger/actions/workflows/tests.yml)

## Features

* Post information to messenger channel
  * post issue updates
  * post private issue updates
  * display watchers
  * convert username to mentions
  * post wiki updates
  * post db entry (if redmine_db is installed) updates
  * post password (if redmine_passwords is installed) updates
  * post contact (if redmine_contacts is installed) updates
* Post information directly to users to be notified (users names should be the same in Redmine and chat). Tested with Rocket.Chat
* overwrite messenger settings at project level
* parent project support (inherit messenger settings from parent project)
* multiple channel support (define one or more channels to deliver note)

## Screenshot

Rocket.Chat output:

![screenshot](https://raw.githubusercontent.com/alphanodes/redmine_messenger/master/assets/images/screenshot_rocketchat.png)

Redmine configuration:

![screenshot](https://raw.githubusercontent.com/alphanodes/redmine_messenger/master/assets/images/screenshot_redmine_settings.png)

* **Convert names to mentions:** Automatically converts Redmine mentions into Slack mentions so a user is notified through Slack when mentioned in a Redmine note. Depends on Redmine Mentions plugin.

* **Display watchers:** Issue watchers are included in notifications.

* **Post issue updates:** All newly created notes on an issue generate a notification (does not include private issues).

* **Description in new issue:** Include the text description of a new issue in the notification.

* **Description in update issue:** Include the text encompassed in a note upon updating the issue in the notification.

* **Post updates for private issue:** Same as *Post issue updates* but for private issues.

* **Post private notes:** Same as *Description in update issue* but for private issues.

* **Post wiki updates:** Generates a notification when a projects Wiki is updated.

## Prepare your messenger service

### Slack

Go to Slack documentation [Incoming Webhooks](https://api.slack.com/incoming-webhooks) for more information to set up Incoming WebHook

### Mattermost

Go to Mattermost documentation [Incoming Webhooks](https://docs.mattermost.com/developer/webhooks-incoming.html) for more information to set up Incoming WebHook

### Discord

Go to Discord documentation [Intro to Webhooks ](https://support.discordapp.com/hc/en-us/articles/228383668) for more information to set up Incoming WebHook
You have to add /slack after your webhook url.

### Rocket.Chat

Go to Rocket.Chat documentation [Incoming WebHook Scripting](https://rocket.chat/docs/administrator-guides/integrations/) for more information to set up Incoming WebHook

### LINE

LINE notifications use the [LINE Messaging API](https://developers.line.biz/en/reference/messaging-api/).

1. Create a Messaging API channel in the [LINE Developers Console](https://developers.line.biz/console/) and issue a **channel access token**.
2. Pick the endpoint URL:
   * `https://api.line.me/v2/bot/message/broadcast` — sends to every user that has added your bot. Leave the *Messenger Channel* field blank.
   * `https://api.line.me/v2/bot/message/push` — sends to a specific user / group / room. Put the recipient ID(s) in the *Messenger Channel* field; multiple IDs can be comma-separated and will each receive a copy.
3. In the plugin settings choose **Messenger type = LINE Messaging API**, paste the token into **Access token (LINE)**, and put the chosen endpoint URL into **Messenger URL**.

### Two destinations at the same time

The plugin exposes two notification "slots" (#1 and #2) in both the global admin area and per-project settings. Whenever Redmine fires a notification it is delivered to *both* slots if both are configured. Typical use case: keep posting to your team's Discord channel while also pushing the same alert to a LINE group.

## Requirements

* Redmine version >= 5.0
* Ruby version >= 2.7.0

### Older versions

* If you want to use it with Redmine 3.x, use git tag 1.0.5
* If you want to use it with Redmine 4.0, use git tag 1.0.7
* If you want to use it with Redmine 4.1, use git tag 1.0.13
* If you want to use it with Redmine 4.2, use git tag 1.0.14

## Installation

Install ``redmine_messenger`` plugin for `Redmine`

    cd $REDMINE_ROOT
    git clone https://github.com/AlphaNodes/redmine_messenger.git plugins/redmine_messenger
    bundle config set --local without 'development test'
    bundle install
    bundle exec rake redmine:plugins:migrate RAILS_ENV=production

Make sure that the directory is named `redmine_messenger` (you cannot use another name for it)!
Restart Redmine (application server) and you should see the plugin show up in the Plugins page.
Under the configuration options, set the Messenger API URL to the URL for an
Incoming WebHook integration in your Messenger account and also set the Messenger
Channel to the channel's handle (be careful, this is not the channel's display name
visible to users, you can find each channel's handle by navigating inside the channel
and clicking the down-arrow and selecting view info).

## Uninstall

Uninstall ``redmine_messenger``

    cd $REDMINE_ROOT
    bundle exec rake redmine:plugins:migrate NAME=redmine_messenger VERSION=0 RAILS_ENV=production
    rm -rf plugins/redmine_messenger

Restart Redmine (application server)

## License

*redmine_messenger* plugin is developed under the [MIT License](LICENSE).

## Redmine Copyright

The redmine_messenger is a plugin extension for Redmine Project Management Software, whose Copyright follows.
Copyright (C) 2006-  Jean-Philippe Lang

Redmine is a flexible project management web application written using Ruby on Rails framework.
More details can be found in the doc directory or on the official website <http://www.redmine.org>

This program is free software; you can redistribute it and/or modify it under the terms of the GNU General Public License as published by the Free Software Foundation; either version 2 of the License, or (at your option) any later version.

This program is distributed in the hope that it will be useful, but WITHOUT ANY WARRANTY; without even the implied warranty of
MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU General Public License for more details.

You should have received a copy of the GNU General Public License along with this program; if not, write to the Free Software Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301, USA.

## Credits

The source code is forked from

* [redmine_rocketchat](https://github.com/phlegx/redmine_rocketchat)
* [redmine_mattermost](https://github.com/altsol/redmine_mattermost)
* [redmine-slack](https://github.com/sciyoshi/redmine-slack)

Special thanks to the original author and contributors for making this awesome hook for Redmine. This fork is just refactored to use Messenger-namespaced configuration options in order to use all hooks for Rocket.Chat, Mattermost AND Slack in a Redmine installation.
