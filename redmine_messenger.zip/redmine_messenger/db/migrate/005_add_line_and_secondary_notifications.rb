# frozen_string_literal: true

class AddLineAndSecondaryNotifications < ActiveRecord::Migration[4.2]
  def change
    change_table :messenger_settings, bulk: true do |t|
      # Primary endpoint: protocol type (slack-compatible webhook or LINE Messaging API)
      # and an auth token used by LINE.
      t.string :messenger_type, default: 'slack', null: false
      t.string :messenger_token

      # Secondary endpoint (notifications can be delivered to two destinations
      # at the same time, e.g. Discord + LINE).
      t.string  :messenger_url2
      t.string  :messenger_type2, default: 'slack', null: false
      t.string  :messenger_channel2
      t.string  :messenger_token2
      t.string  :messenger_icon2
      t.string  :messenger_username2
    end
  end
end
