# frozen_string_literal: true

module RedmineMessenger
  module Patches
    module ContactPatch
      extend ActiveSupport::Concern

      included do
        include InstanceMethods

        after_create_commit :send_messenger_create
        after_update_commit :send_messenger_update
      end

      module InstanceMethods
        def send_messenger_create
          return unless Messenger.setting_for_project project, :post_contact
          return if is_private? && !Messenger.setting_for_project(project, :post_private_contacts)

          return unless Messenger.deliverable?(project)

          channels = Messenger.channels_for_project project
          url = Messenger.url_for_project project

          initial_language = ::I18n.locale
          begin
            set_language_if_valid Setting.default_language

            line_card = {
              action: :created,
              entity_type: :contact,
              title: name.to_s,
              url: Messenger.object_url(self),
              user: User.current.to_s,
              project_name: project.name
            }

            Messenger.speak l(:label_messenger_contact_created,
                              project_url: Messenger.project_url_markdown(project),
                              url: Messenger.url_markdown(self, name),
                              user: User.current),
                            channels, url, project: project, line_card: line_card
          ensure
            ::I18n.locale = initial_language
          end
        end

        def send_messenger_update
          return unless Messenger.setting_for_project project, :post_contact_updates
          return if is_private? && !Messenger.setting_for_project(project, :post_private_contacts)

          return unless Messenger.deliverable?(project)

          channels = Messenger.channels_for_project project
          url = Messenger.url_for_project project

          initial_language = ::I18n.locale
          begin
            set_language_if_valid Setting.default_language

            line_card = {
              action: :updated,
              entity_type: :contact,
              title: name.to_s,
              url: Messenger.object_url(self),
              user: User.current.to_s,
              project_name: project.name
            }

            Messenger.speak l(:label_messenger_contact_updated,
                              project_url: Messenger.project_url_markdown(project),
                              url: Messenger.url_markdown(self, name),
                              user: User.current),
                            channels, url, project: project, line_card: line_card
          ensure
            ::I18n.locale = initial_language
          end
        end
      end
    end
  end
end
